# `models` folder
Make sure this folder contains these two files:
1.  `classes.txt`
2.  `model.pkl`

Our versions of these two files can be downloaded here from .       

**Releases**:     
https://github.com/npatta01/web-deep-learning-classifier/releases  

`wget https://github.com/npatta01/web-deep-learning-classifier/releases/download/v1.0.1/classes.txt`  
`wget https://github.com/npatta01/web-deep-learning-classifier/releases/download/v1.0.1/model.pkl`
